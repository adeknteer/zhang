<template>
<div>
    <van-swipe class="my-swipe" :autoplay="3000" indicator-color="white">
    <van-swipe-item v-for="(v,i) in banner" :key="i">
             <img :src="v.picUrl" alt="">
    </van-swipe-item>
    </van-swipe>
     <ul>
        <li>
            <img src="/static/tu1.png" alt="">
            <p>签到</p>
        </li>
         <li>
            <img src="/static/tu2.png" alt="">
            <p>礼卷</p>
        </li>
         <li>
            <img src="/static/tu3.png" alt="">
            <p>砍价</p>
        </li>
         <li>
            <img src="/static/tu2.png" alt="">
            <p>专价</p>
        </li>
    </ul>
</div>
</template>

<script>
export default {
  name:"banner",
  data(){
      return{
          banner:[]
      }
  },
  created(){
      this.http.get("https://api.it120.cc/small4/banner/list").then(res=>{
          console.log(res)
          this.banner=res.data.data
      })
  }
}
</script>

<style lang="scss" scoped>
  div{
     height:4.81rem;
    position: relative;
  }
  
  img{
      width: 100%;
  }
  ul{
      display: flex;
      width: 100%;
      border-radius: 20% 20% 0% 0%;
      background: white;
      position: absolute;
        overflow: hidden;
        bottom: 0;left: 0;
      li{
          width: 25%;
          img{
              width: 0.58rem;
              margin: 0 auto;
              display: block;
          }
          p{
              text-align: center;
              font-size: 0.20rem;
              line-height: 0.40rem;
          }
      }
  }
 
</style>