<template>
  <div class="jingxuan">
    <div class="tou">
      <p>精选标题</p>
      <i class="van-icon van-icon-arrow"></i>
    </div>
    <div class="nei">
      <ul>
        <li v-for="(v,i) in taozhuan" :key="i" @click="go(v.id)">
          <img :src="v.pic" alt />
          <p>{{v.title}}</p>
          <p class="p1">{{v.descript}}</p>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      taozhuan: []
    };
  },
  methods: {
    go(id) {
      this.$router.push("/taozhuan?id=" + id);
    }
  },
  created() {
    this.http.get("https://api.it120.cc/small4/cms/news/list ").then(res => {
      console.log(res);
      this.taozhuan = res.data.data;
    });
  }
};
</script>

<style lang="scss">
.jingxuan {
  width: 100%;
  border-bottom: 0.14rem solid #f5f5f5;
  .tou {
    font-size: 0.22rem;
    display: flex;
    justify-content: space-around;
    align-items: center;
    text-align: center;
    i {
      display: block;
      margin-left: -4rem;
    }
  }
  .nei {
    height: 4.6rem;
    overflow: auto;
    ul {
      width: 22.7rem;
      display: flex;
      li {
        width: 4.42rem;
        height: 2.84rem;
        margin-left: 0.12rem;
        img {
          width: 4.42rem;
          height: 2.84rem;
          display: block;
          border-radius: 0.06rem;
        }
        .p1 {
          overflow: hidden;
          text-overflow: ellipsis;
          font-size: 0.14rem;
          color: #a8a8a8;
          margin-top: 0.2rem;
          width: 3.24rem;
          white-space: nowrap;
        }
      }
    }
  }
}
</style>