document.getElementsByTagName('html')[0].style['font-size']=document.documentElement.clientWidth/5.3+"px"
