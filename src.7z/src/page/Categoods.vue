<template>
  <div class="wrapper">
    <van-nav-bar title="分类商品" left-arrow :border="f" @click-left="onClickLeft" />
    <ul id="classify" v-if="list.length!=0">
      <li class v-for="item of list" :key="item.id" @click="goxiang(item.id)">
        <img :src="item.pic" alt />
        <p>{{item.name}}</p>
        <p>￥{{item.originalPrice}}</p>
      </li>
    </ul>
    <img v-else class="classify_img" src="/static/tu4.png" alt  />
  </div>
</template>
<script>
export default {
  name: "",
  props: {},
  components: {},
  data() {
    return {
      list: [],
      f: false
    };
  },
  watch: {},
  computed: {},
  watch: {},
  methods: {
    onClickLeft() {
      this.$router.go(-1); 
    
    },
      goxiang(id){
      this.$router.push({name:"shangpin",params:{id}})
      console.log(id)
    }
  },
  created() {
      console.log(this.$route.query.cid)
    this.http.get("https://api.it120.cc/small4/shop/goods/list?id="+this.$route.query.cid).then(msg => {
    //   console.log(msg);
      if (msg.data.msg == "success") {
        this.list = msg.data.data.filter(item => {
          return item.categoryId == this.$route.query.cid;
        });
      }
    console.log(msg)
    })
   
  },
  mounted() {},
  beforeDestroy() {}
};
</script>
<style lang='scss' scoped>
.wrapper {
  .van-nav-bar {
    .van-icon {
      color: #000;
    }
  }
}
.classify_img {
  img {
    width: 100%;
    margin-top: 2rem;
  }
}
#classify {
  margin-top: 0.7rem;
  display: flex;
  justify-content: space-between;
  padding: 0 0.1rem;
  flex-wrap: wrap;
  li {
    width: 2.45rem;
    position: relative;
    img {
      width: 100%;
    }
    p:nth-of-type(1) {
      position: absolute;
      left: 0;
      top: 2rem;
      width: 100%;
      height: 0.4rem;
      background: #f0edd4;
      font-size: 0.14rem;
      color: #b69b72;
      text-indent: 0.02rem;
      line-height: 0.4rem;
    }
    p:nth-of-type(2) {
      font-size: 0.2rem;
      color: #cf1311;
      position: absolute;
      left: 0;
      top: 2.5rem;
    }
  }
}
.classify_img {
  width: 100%;
  margin-top: 2rem;
}
</style>