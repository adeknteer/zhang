<template>
  <div>
    <van-nav-bar title="专栏详情" left-arrow @click-left="onClickLeft" />
    <ul>
      <li>
        <p>{{list.title}}</p>
        <img :src="list.pic" alt />
        <div class="zhy" v-html="list.content">

        </div>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: "taozhuan",
  data() {
    return {
      list: []
    };
  },
  created() {
    this.http
      .get(
        "https://api.it120.cc/small4/cms/news/detail?id=" + this.$route.query.id
      )
      .then(res => {
        console.log(res);
        this.list = res.data.data;
      });
  },
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    }
  }
};
</script>

<style  lang="scss">
ul {
  li {
      p{
          text-align:center;
          font-size: 0.30rem;

      }
    img {
      width: 4.85rem;
      height: 3.13rem;
      display: block;
      margin: 0 auto;
    }
  }
  .zhy{
      p{
          font-size: 0.2rem;
          color: #333333;
          line-height: 0.48rem;
          text-indent: 2em;
        margin-top: 0.1rem;
}
      }
  }

</style>
