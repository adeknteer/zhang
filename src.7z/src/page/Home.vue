<template>
<div>
  <router-view></router-view>
  <van-tabbar route>
  <van-tabbar-item replace to="/home/index" icon="home-o">
    首页 
  </van-tabbar-item>
  <van-tabbar-item replace to="/home/cate" icon="search">
    分类 
  </van-tabbar-item>
  <van-tabbar-item replace to="/home/cart"   badge="521" icon="home-o">
    购物车
  </van-tabbar-item>
  <van-tabbar-item replace to="/home/user" icon="search">
    我的
  </van-tabbar-item>
</van-tabbar>
</div>
</template>
<script>

export default {
   
   
}
</script>

<style>

</style>