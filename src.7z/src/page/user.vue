<template>
   <div>
      用户
      <button @click="tui">退出</button>
  </div>
</template>
<script>
export default {
  name: '',
  props: {},
  components: {},
  data() {
    return {};
  },
  computed: {},
  watch: {},
  methods: {
  tui(){
     localStorage.removeItem("aa")
     this.$router.push("/denglu")
  }
},
  created() {},
  mounted() {},
  beforeDestroy() {}
};
</script>
<style lang='scss' scoped>
</style>