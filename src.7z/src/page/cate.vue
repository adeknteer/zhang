<template>
  <div class="fenlei">
    <p class="zi">
      <input type="text" placeholder="回车搜索商品" />
    </p>
    <div class="zi1">
      <ol>
        <li class="feired" @click="all" :class="{'active':n==0}">所有分类</li>
        <li
          class="feired"
          v-for="(item,index) of ni"
          :key="item.id"
          @click="ii(item.id,index+1)"
          :class="{'active':(index+1)==n}"
        >{{item.name}}</li>
      </ol>
      <div class="zi2">
        <ul>
          <li v-for="(item,index) of ta" :key="item.id" @click="qq(item.id)">
            <img :src="item.icon" alt />
            <p>{{item.name}}</p>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "",
  props: {},
  components: {},
  data() {
    return {
      ni: [],
      wo: [],
      ta: [],
      n: 0
    };
  },
  computed: {},
  watch: {},
  methods: {
    async qu() {
      var a = await this.http.get(
        "https://api.it120.cc/small4/shop/goods/category/all"
      );
      console.log(a);
      if (a.data.msg == "success") {
        var b = a.data.data.filter(item => {
          return item.level == 1;
        });
      }
      this.ni = b;
      // console.log(this.ni);
      this.wo = a.data.data;
      this.ta = a.data.data;

      //  console.log(this.ta)//
    },
    ii(id, i) {
      var e = this.wo.filter(itm => {
        return itm.pid == id;
      });
      this.ta = e;
      // console.log(this.ta);
      this.n = i;
    },
    all() {
      console.log(this.wo);
      console.log(this.ta);
       this.ta=this.wo
      this.n = 0;
    },
    qq(id){
      this.$router.push("/categoods?cid="+id)
    }
  },
  created() {
    this.qu();
  },
  mounted() {},
  beforeDestroy() {}
};
</script>
<style lang='scss' scoped>
.fenlei {
  .zi {
    width: 100%;
    height: 0.5rem;
    border-bottom: 0.01rem solid #f3f3f3;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    input {
      width: 3.43rem;
      height: 0.35rem;
      background: #f5f5f5;
      border: none;
      border-radius: 0.2rem;
      margin-left: 0.2rem;
      padding-left: 0.2rem;
    }
  }
  .zi1 {
    display: flex;
    ol {
      width: 1.27rem;
      border-right: 0.01rem solid #e9e9e9;
      height: 100%;
      position: fixed;
      left: 0;
      top: 0.51rem;
      overflow: auto;
      background: white;
      z-index: 1;

      li {
        width: 1.27rem;
        height: 0.5rem;
        font-size: 0.2rem;
        text-align: center;
        line-height: 0.5rem;
        margin-top: 0.1rem;
      }
    }
  }
  .zi2 {
    margin-left: 1.5rem;
    ul {
      display: flex;
      -webkit-box-pack: justify;
      -ms-flex-pack: justify;
      justify-content: space-between;
      -ms-flex-wrap: wrap;
      flex-wrap: wrap;
      width: 3.72rem;
      text-align: center;
      padding: 0 0.1rem;
      li {
        width: 30%;
        margin-top: 0.1rem;
        img {
          width: 1.1rem;
          height: 1.1rem;
          display: block;
        }
      }
    }
  }
}
.feired.active {
  border-left: 1px red solid;
  color: red;
}
</style>