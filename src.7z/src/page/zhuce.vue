<template>
  <div class="yonghu">
    <div>
      <h2>新用户注册</h2>
      <p>很高兴您将能成为我们得会员（注册只需要一步）</p>
      <p class="zi">
        <input autofocus="autofocus" type="tel" placeholder="手机号码" v-model="tel" />
        <span style="display:none">必填</span>
       <van-icon name= "phone-o" />
      </p>
      <p class="zi2">
        <input type="password" placeholder="密码"  v-show="zh" v-model="pwd">
        <input type="text" placeholder="密码" v-show="!zh" v-model="pwd">
        <i class="van-icon van-icon-closed-eye" v-show="zz"  @click="zzz"></i>
        <i class="van-icon van-icon-eys-o"  v-show="!zz" @click="zzz"></i>
      </p>
      <p class="zi3">
       <input type="password" placeholder="密码"  v-show="zh" v-model="pwd">
        <input type="text" placeholder="密码" v-show="!zh" v-model="pwd">
        <i class="van-icon van-icon-closed-eye" v-show="zz"  @click="zzz"></i>
        <i class="van-icon van-icon-eys-o"  v-show="!zz" @click="zzz"></i>
      </p>
      <p class="zi4">
      <input type="text" placeholder="用户名" >
      <i class="van-icon van-icon-manager"></i>
      </p>
       <p class="zi5">
      <input type="text" placeholder="" >
      <img :src="tu+key" alt="" @click="pp">
      </p>
      <p class="zi6">
        <input type="text" v-model="code">
        <span @click="zhuce" v-show="flag">获取验证码</span>
        <span v-show="!flag">{{tt}}后重发 </span>
      </p>
      <p @click="goCode" class="zi7">立即注册</p>
      <p class="zi8">已有账号？立即登录</p>
    </div>
  </div>
</template>
<script>
import { v4 as uuidv4 } from 'uuid';
import qs from "qs";
export default {
  name: "",
  props: {},
  components: {},
  data() {
    return {
       tu:"https://api.it120.cc/small4/verification/pic/get?key=",
       key:uuidv4(),
       tel:"",
        pic:"",
        pwd:"",
        code:"",
        flag:true,
        tt:0,
        zz:true,
        zh:true,
        }
  },
  computed: {},
  watch: {},
  methods: {
      pp(){
        this.key=uuidv4()
      },
       zhuce(){
           
           //alert(this.tel)
           var data = {"mobile":this.tel,"picCode":this.pic,"key":this.key}
           
           this.http.post("https://api.it120.cc/small4/verification/sms/get",qs.stringify(data)).then((msg)=>{
               console.log(msg)
           })
           this.flag=false;
           this.tt=60;
           var time=setInterval(()=>{
            this.tt--;
            if(this.tt<=0){
            this.flag=true;
            clearInterval(time) 
            }
           },10)
         
      },
      goCode(){
        var data={"mobile":this.tel,pwd:this.pwd,code:this.code}
        this.http.post("https://api.it120.cc/small4/user/m/register",qs.stringify(data)).then((msg)=>{
          console.log(msg)

        })  

      },
      zzz(){
        this.zh=!this.zh
      },
      
  },
  created() {},
  mounted() {},
  beforeDestroy() {}
};
</script>
<style lang='scss' scoped>
.yonghu {
  padding: 0.26rem;
  min-height: 2rem;

  div{
    width: 3.84rem;
    padding: 0 0.44rem;
    border: 0.02rem solid #f5f5f5;
    min-height: 10rem；;
  }
}

.zi {
  width: 3.72rem;
  height: 0.65rem;
  background: #f5f5f5;
  align-items: center;
  position: relative;
  display: flex;
  input {
    margin-left: 0.2rem;
    width: 2.6rem;
    height: 0.4rem;
    border: none;
    outline: none;
    background: #f5f5f5;
    font-size: 0.2rem;
    color: #bfbfbf;
  }
  i {
    font-size: 0.22rem;
    color: #d1cfce;
    position: absolute;
    left: 3.3rem;
    top: 0.24rem;
  }
}
.zi2{
  width: 3.72rem;
  height: 0.66rem;
  border-radius: 0.08rem;
  background: #f5f5f5;
  margin-top: 0.24rem;
  display: flex;
  -webkit-box-align: center;
  align-items: center;
  position: relative;
  border: 1px solid #f5f5f5;
  input{
     margin-left: 0.2rem;
    width: 2.6rem;
    height: 0.4rem;
    border: none;
    outline: none;
    background: #f5f5f5;
    font-size: 0.2rem;
    color: #bfbfbf;
  }
  i{
    font-size: 0.22rem;
    color: #d1cfce;
    position: absolute;
    left: 3.3rem;
  }
}
.zi3{
    width: 3.72rem;
    height: 0.66rem;
    border-radius: 0.08rem;
    background: #f5f5f5;
    margin-top: 0.24rem;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    position: relative;
    border: 1px solid #f5f5f5;
    input{
      margin-left:0.2rem;
      width:2.6rem;
      height: 0.4rem;
      border:none;
      outline:none;
      background:#f5f5f5 ;
      font-size: 0.2rem;
      color:#bfbfbf;
    }
    i{
      font-size: 0.22rem;
      color: #d1cfce;
      position: absolute;
      left: 3.3rem;
    }
  }
  .zi4{
    width: 3.72rem;
    height: 0.66rem;
    border-radius: 0.08rem;
    background: #f5f5f5;
    margin-top: 0.24rem;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    position: relative;
    border: 1px solid #f5f5f5;
    input{
      margin-left:0.2rem;
      width:2.6rem;
      height: 0.4rem;
      border:none;
      outline:none;
      background:#f5f5f5 ;
      font-size: 0.2rem;
      color:#bfbfbf;
    }
    i{
      font-size: 0.22rem;
      color: #d1cfce;
      position: absolute;
      left: 3.3rem;
    }
  }
  .zi5{
     width: 3.72rem;
    height: 0.66rem;
    border-radius: 0.08rem;
    background: #f5f5f5;
    margin-top: 0.24rem;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    position: relative;
    border: 1px solid #f5f5f5;
     input{
      margin-left:0.2rem;
      width:2.6rem;
      height: 0.4rem;
      border:none;
      outline:none;
      background:#f5f5f5 ;
      font-size: 0.2rem;
      color:#bfbfbf;
    }
    img{
      width: 2rem;
      height: 0.65rem;
      position: absolute;
      right: 0;
      top: 0;
    }
  }
  .zi6{
     width: 3.72rem;
    height: 0.66rem;
    border-radius: 0.08rem;
    background: #f5f5f5;
    margin-top: 0.24rem;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    position: relative;
    border: 1px solid #f5f5f5;
    input{
      margin-left:0.2rem;
      width:2.6rem;
      height: 0.4rem;
      border:none;
      outline:none;
      background:#f5f5f5 ;
      font-size: 0.2rem;
      color:#bfbfbf;
    }
  }
  .zi7{
     width: 2.91rem;
    height: 0.67rem;
    border-radius: 0.06rem;
    background:linear-gradient(90deg,#5ea6f8,#bb87f6);
   text-align: center;
   line-height: 0.57rem;
   font-size: 0.2rem;
   color: white;
   letter-spacing: 0.06rem;
   margin: 0 auto;
   margin-top:0.24rem ;
  }
  .zi8{
    font-size: 0.2rem;
    color: #549ff9;
    margin-top:0.27rem ;
    text-align: center;
  }
</style>