<template>
<div>
  <banner></banner>
   <kj></kj>
   <jingxuan></jingxuan>
  
   </div>

</template>

<script>
import banner from "../components/banner"
import kj from "../components/kj"
import jingxuan from "../components/jingxuan"

export default {
    components:{banner,kj,jingxuan}

}
</script>

<style>

</style>