<template>
  <div class='wrapper'>
    <div>
    
<van-swipe :autoplay="3000">
  <van-swipe-item v-for="(image, index) in image" :key="index">
    <img v-lazy="image.pic" />
  </van-swipe-item>
</van-swipe>    
    </div>
    <div class="zi">
        <p class="zi1">{{zhang.name}}</p>
         <p class="zi2">{{zhang.characteristic}}</p>
        <p class="zi3">{{zhang.minPrice}}</p>
        <P class="zi4">{{zhang.originalPrice}}</P>
        <p class="zi5">{{zhang.stores}}</p>
    </div>
    <div class="ta" v-html="ni">
        
    </div>
    <!-- <van-cell is-link @click="showPopup">展示弹出层</van-cell>
<van-popup v-model="show"> -->
    
<!-- </van-popup> -->
</div>
</template>
<script>
import { Lazyload } from 'vant';
export default {
  name: '',
  props: {},
  components: {},
  data() {
    return {
    image:[],
    zhang:[],
    ni:"",
    show:""
};
  },
  computed: {
   
},
  watch: {},
  methods: {
    showPopup(){
        this.show=true;
    }
},
  created() {
     var id = this.$route.params.id;

    this.http.get("https://api.it120.cc/small4/shop/goods/detail?id="+id).then(msg=>{
        this.image=msg.data.data.pics
        console.log(msg.data.data.content)
        console.log(this.image)
        console.log(msg)
        this.zhang=msg.data.data.basicInfo
        this.ni=msg.data.data.content
        console.log(this.ni)

    })
    
    
},
  mounted() {},
  beforeDestroy() {}
};
</script>
<style lang='scss'  >
.my-swipe .van-swipe-item {
    color: #fff;
    font-size: 20px;
    line-height: 150px;
    text-align: center;
    background-color: #39a9ed;
  
  }
    .ta{
      width: 100%   !important;
      height: 100%;
      overflow: auto;
      .img-lazyloaded {
          width: 100%  !important;
          height: 100%  !important;
      }
  }
  .zi{
      width: 5rem;
    height: 1.24rem;
    background: #FFFFFF;
    padding-left: 0.2rem;
    border-bottom: 0.14rem solid #F5F5F5;

     .zi1{
      font-size: 0.22rem;
    color: #464646;
    margin-top: 0.3rem;
  }
  .zi2{
      font-size: 0.16rem;
    color: #B8B8B8;
    margin-top: 0.16rem;
  }
  .zi3{
      font-size: 0.14rem;
    color: #CC0C0C;
    width: 0.9rem;
  }
  .zi4{
      font-size: 0.14rem;
    color: #B8B8B8;
    margin-top: 0.06rem;
    width: 3.4rem;
  }
  .zi5{
          font-size: 0.14rem;
    color: #B8B8B8;
    margin-top: 0.06rem;
  }
  }
 
  
</style>