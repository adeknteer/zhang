<template>
  <div class='wrapper'>
  购物车
</div>
</template>
<script>
export default {
  name: '',
  props: {},
  components: {},
  data() {
    return {};
  },
  computed: {},
  watch: {},
  methods: {},
  created() {},
  mounted() {},
  beforeDestroy() {}
};
</script>
<style lang='scss' scoped>
</style>