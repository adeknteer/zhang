<template>
  <div class="wrapper">
    <p class="zi">登录账号</p>
    <p class="zi1">虾米-严选商城欢迎您</p>
    <p class="zi2">
      <input type="text" placeholder="请输入手机号" v-model="tel"  autofocus="autofocus" />
      <span class="s2">必填</span>
      <van-icon name="phone-o" />
    </p>
    <p class="zi3">
      <input type="password" placeholder="密码" autofocus="autofocus" v-show="zh" v-model="pwd" />
      <input type="text" placeholder="密码" autofocus="autofocus" v-show="!zh" v-model="pwd" />
      <span class="s2">密码</span>
      <i class="van-icon van-icon-closed-eye" v-show="zz" @click="zzz"></i>

      <i class="van-icon van-icon-eys-o" v-show="!zz" @click="zzz"></i>
    </p>
    <div class="pay">
      <a data-animation="ripple" @click="gode">登 
           <span class="s1" style="font-weight:bold">录</span>
           </a>
    </div>
    <p class="pp">忘记密码</p>
    <p class="ppp">还没有注册？立即注册</p>
  </div>
</template>
<script>
import qs from "qs";
export default {
  name: "",
  props: {},
  components: {},
  data() {
    return {
      zz: true,
      zh: true,
      pwd: "",
      tel:""
    };
  },
  computed: {},
  watch: {},
  methods: {
    zzz() {
      this.zh = !this.zh;
    },
    gode(){
        var data={"mobile":this.tel,pwd:this.pwd}
        this.http.post("https://api.it120.cc/small4/user/m/login?deviceId=007&deviceName=monkey",qs.stringify(data)).then((msg)=>{
          console.log(msg)
     if(msg.data.msg=="success"){
         localStorage.setItem("aa",msg.data.data.token)
         this.$router.push("/home/user")
     }else{
         alert("密码或账号不正确")
     }
        })  
    }
  },
  created() {},
  mounted() {},
  beforeDestroy() {}
};
</script>
<style lang='scss' scoped>
.wrapper {
  width: 3.8rem;
  height: 0.44rem;
  height: 8rem;
  border: 0.2rem solid #f5f5f5;
  border-radius: 0.06rem;
  margin: 0 auto;
  .zi {
    font-size: 0.3rem;
    color: #666;
    margin-top: 0.44rem;
    margin-left: 0.2rem;
  }
  .zi1 {
    font-size: 0.2rem;
    color: #909090;
    margin-top: 0.36rem;
    margin-left: 0.2rem;
  }
  .zi2 {
    width: 3.72rem;
    height: 0.66rem;
    border-radius: 0.08rem;
    margin-top: 0.44rem;
    display: flex;
    // -webkit-box-align: center;
    align-items: center;
    position: relative;
    background: #f5f5f5;
    border: 1px solid #f5f5f5;
  }
  input {
    margin-left: 0.2rem;
    width: 2.6rem;
    height: 0.4rem;
    border: none;
    outline: none;
    font-size: 0.2rem;
    background: #f5f5f5;
  }
  .s2 {
    font-size: 0.18rem;
    color: red;
  }
  .zi3 {
    width: 3.72rem;
    height: 0.66rem;
    border-radius: 0.08rem;
    margin-top: 0.44rem;
    display: flex;
    // -webkit-box-align: center;
    align-items: center;
    position: relative;
    background: #f5f5f5;
    border: 1px solid #f5f5f5;
  }
  input {
    margin-left: 0.2rem;
    width: 2.6rem;
    height: 0.4rem;
    border: none;
    outline: none;
    font-size: 0.2rem;
    background: #f5f5f5;
  }
  .pay {
    height: 50px;
    width: 200px;
    margin-left: 0.46rem;
    font-size: 0.2rem;
    margin-top: 0.3rem;
    a {
      height: 100%;
      width: 2.9rem;
      display: block;
      outline: none;
      padding: 20px;
      color: #fff;
      text-transform: uppercase;
      background: linear-gradient(135deg, #e570e7 0%, #79f1fc 100%);
      box-sizing: border-box;
      text-align: center;
      line-height: 14px;
      font-family: roboto, helvetica;
      font-weight: 2000;
      letter-spacing: 1px;
      text-decoration: none;
      box-shadow: 0 5px 3px rgba(0, 0, 0, 0.3);
      cursor: pointer;
      -webkit-tap-highlight-color: transparent;
      border-radius: 5px;
    }
   
  } .s1 {
      font-weight: bold;
    }
    .pp{
        font-size: 0.16rem;
        color: #989898;
        text-align: center;
        margin: 0.36rem;
    }
    .ppp{
        color: #549ff9;
        width: 100%;
        text-align: center;
        margin-top: 0.38rem;
        font-size: 0.2rem;
    }
    
}
</style>