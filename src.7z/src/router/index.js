import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import Home from '../page/Home'
import Index from '../page/Index'
import Cart from '../page/Cart'
import user from '../page/user'
import cate from  '../page/cate'
import taozhuan from "../page/taozhuan"
import zhuce from "../page/zhuce"
import denglu from "../page/denglu"
import Categoods from "../page/Categoods"
import shangpin from "../page/shangpin"


Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'HelloWorld',
      component: HelloWorld,
      redirect:'/home'
    },
    {
      path: '/home',
      name: 'home',
      component:Home,
      redirect:'/home/index',
      children:[
        {
          path:'index',
          component:Index
        },
        {
          path:'user',
          component:user
        },
        {
          path:'cart',
          component:Cart
        },
        {
          path:'cate',
          component:cate
        }
        
      ]
    },
    {
      path:'/taozhuan',
      component:taozhuan
    },
      {
        path: '/zhuce',
        component: zhuce
      },
      {
        path:'/denglu',
        component:denglu
      },
      {
        path:'/categoods',
        component:Categoods
      },
      {
        path:'/shangpin/:id',
        name:"shangpin",
        component:shangpin
      }
    

  ]
})
